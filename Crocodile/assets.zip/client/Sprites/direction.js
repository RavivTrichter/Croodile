export const DIRECTIONS = {
	LEFT: 0,
	UP: 90,
	RIGHT: -180,
	DOWN: -90
};