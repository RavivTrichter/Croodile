## To add code to this project:
1. Clone this repository to your PC
2. Create a new branch in github based on the master branch
3. In your PC Move to that branch and work on it (you might have to PULL before)
4. Commit your code to that branch
5. Push to that branch **( not the master branch!)**
6. Go into github and create a pull request from the branch you opened to master
